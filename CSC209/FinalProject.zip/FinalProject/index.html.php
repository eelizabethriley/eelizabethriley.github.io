<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/index.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="topnav">
  <a class="active" href="index.html.php">Home</a>
  <a href="timer.html.php">Timer</a>
  <a href="login.html.php">Login</a>
  <a href="todo.html.php">To Do</a>
  <a href="profile.html.php">Profile</a>
</div>
<h1>Welcome To TaskTabby!</h2>

<div class="main-container center">
	<p>a productivity timer and to-do list</p>
</div>
<div class="footer">
  <p>Created by Erin Riley 2025</p>
</div>

</body>
</html>
