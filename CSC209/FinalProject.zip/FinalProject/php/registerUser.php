<html>
<head>
<link rel="stylesheet" href="../css/style.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
$output = "../output/users.json";
if (file_exists($output)) {
    $current = file_get_contents($output);
    $users = json_decode($current, true);
}
else {
	$users = [];
}

$username = $_POST["uname"];
$password = $_POST["psw"];

// Prevent duplicate usernames
foreach ($users as $user) {
    if ($user["username"] === $username) {
        exit ("ERROR: username already exists.");
    }
}

$users[] = [
    "username" => $username,
    "password" => $password
];

file_put_contents("../output/users.json", json_encode($users));
?>
<div class="topnav">
  <a href="index.html.php">Home</a>
  <a href="timer.html.php">Timer</a>
  <a href="login.html.php">Login</a>
  <a href="todo.html.php">To Do</a>
  <a class="active" href="profile.html.php">Profile</a>
</div>
Welcome <?php echo $username; ?><br>
Your password is: <?php echo $password; ?>
</body>
</html>