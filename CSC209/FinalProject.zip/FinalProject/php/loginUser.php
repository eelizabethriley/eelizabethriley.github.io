<html>
<head>
    <link rel="stylesheet" href="../css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="topnav">
  <a href="index.html.php">Home</a>
  <a href="timer.html.php">Timer</a>
  <a href="login.html.php">Login</a>
  <a href="todo.html.php">To Do</a>
  <a class="active" href="profile.html.php">Profile</a>
</div>
<?php
session_start();

$output = "../output/users.json";
$loginSuccess = false;
$message = "";

$username = $_POST["uname"];
$password = $_POST["psw"];

if (file_exists($output)) {
    $jsonData = file_get_contents($output);
    $users = json_decode($jsonData, true);

    // Look for a matching user
    foreach ($users as $user) {
        if ($user["username"] === $username && $user["password"] === $password) {
            $loginSuccess = true;
            $_SESSION["username"] = $username;
            // Check for user file or make one
            $userData = "../output/UserData/{$username}.json";
            $lists = [];

            if (!file_exists($userData)) {
                    $userInfo = [
                        "lists" => [],
                        "history" => []
                    ];
                file_put_contents($userData, json_encode($userInfo));
            }
            break;
        }
    }
}

if ($loginSuccess) {
    $message = "Login successful. Welcome, " . ($username) . "!";
} else {
    $message = "Login failed. Invalid username or password.";
}
?>
    <h2><?php echo $message; ?></h2>
</body>
</html>
