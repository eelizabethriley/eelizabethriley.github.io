<?php
echo("You just clicked Submit. More, later...")

?>